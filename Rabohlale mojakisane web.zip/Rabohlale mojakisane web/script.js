
// Dynamic Welcome Message
const welcomeMsg = document.getElementById("welcome-message");
if (welcomeMsg) {
  const now = new Date();
  welcomeMsg.textContent = `Hello Visitor! Today is ${now.toDateString()} - ${now.toLocaleTimeString()}`;
}

// Background Color Changer

window.onload = Greetings;

function BackGround(){
  const colors = ["#350de6", "#ffffff", "#00ff66"];
  const random = Math.floor(Math.random() * colors.length);
  document.body.style.backgroundImage = 'none';
  document.body.style.backgroundColor = colors[random];
  document.body.style.background = colors[random];
}

// Slideshow
let slideIndex = 0;
const slides = document.querySelectorAll(".slide");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");

function showSlide(n) {
  slides.forEach((slide, i) => {
    slide.classList.remove("active");
    if (i === n) slide.classList.add("active");
  });
}
if (slides.length > 0) {
  showSlide(slideIndex);
  if (nextBtn && prevBtn) {

    nextBtn.addEventListener("click", () => {
      slideIndex = (slideIndex + 1) % slides.length;
      showSlide(slideIndex);
    });
    prevBtn.addEventListener("click", () => {
      slideIndex = (slideIndex - 1 + slides.length) % slides.length;
      showSlide(slideIndex);
    });
  }
  setInterval(() => {
    slideIndex = (slideIndex + 1) % slides.length;
    showSlide(slideIndex);
  }, 5000);
}

// About Page Content
const destination = {
  name: "LESOTHO",

  history: "Lesotho offers an array of spectacular attractions that showcase its natural beauty and cultural heritage",
  culture: "The cultural heritage of Lesotho is deeply rooted in traditions that have been preserved for generations",
  attractions: "",
  extra: "Hawaii was annexed by the United States in 1898 and became the 50th state in 1959."
};

const destInfo = document.getElementById("destination-info");
if (destInfo) {
  destInfo.innerHTML = `
    <h2>${destination.name}</h2>
    <p><strong>History:</strong> ${destination.history}</p>
    <p><strong>Culture:</strong> ${destination.culture}</p>

    <p><strong>Attractions:</strong> ${destination.attractions}</p>
    <p id="extraInfo" style="display:none;"><strong>More:</strong> ${destination.extra}</p>
  `;
}

const toggleBtn = document.getElementById("toggleBtn");
if (toggleBtn) {
  toggleBtn.addEventListener("click", () => {
    const extra = document.getElementById("extraInfo");
    if (extra.style.display === "none") {
      extra.style.css.display = "block";
      toggleBtn.textContent = "Show Less";
    } else {
      extra.style.display = "none";
      toggleBtn.textContent = "Show More";
    }

  });
}

// Fun Facts Array
const facts = [
  "Hawaii is the only U.S. state made up entirely of islands.",
  "Surfing was invented in Hawaii.",
  "It is home to the world’s most active volcano, Kilauea."
];
const funFact = document.getElementById("funFact");
if (funFact) {
  funFact.textContent = facts[Math.floor(Math.random() * facts.length)];
}

// Gallery Filtering
function filterImages(category) {

  const items = document.querySelectorAll(".gallery-item");
  items.forEach(img => {
    if (category === "all" || img.classList.contains(category)) {
      img.style.display = "block";
    } else {
      img.style.display = "none";
    }
  });
}

// Lightbox
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightboxImg");
const closeBtn = document.querySelector(".close");

const galleryItems = 

document.querySelectorAll(".gallery-item");
galleryItems.forEach(img => {
  img.addEventListener("click", () => {
    lightbox.style.display = "block";
    lightboxImg.src = img.src;
  });
});

if (closeBtn) {
  closeBtn.addEventListener("click", () => {
    lightbox.style.display = "none";
  });
}

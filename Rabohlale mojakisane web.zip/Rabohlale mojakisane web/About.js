// ----------- ABOUT PAGE (about.html) -----------
if (document.body.contains(document.getElementById("about-content"))) {
  // Data stored in an object
  const aboutData = {
    history: `Lesotho's history is a compelling narrative of resilience and nation-building. 
    The Basotho nation was formed in the early 19th century by King Moshoeshoe I...`,

    culture: `The Basotho people are known for their national attire (colorful blankets), music, dance, and storytelling. 
    These traditions remain central to their identity.`,

    attractions: `Top attractions include: Katse Dam, Sani Pass, Thaba-Bosiu, Maletsunyane Falls, and Sehlabathebe National Park.`
  };

  // Fun facts array
  const funFacts = [
    "Lesotho is the only independent state entirely above 1,000 meters elevation.",
    "The mokorotlo hat design was inspired by Mount Qiloane.",
    "Lesotho has some of the best-preserved dinosaur footprints in the world.",
    "It is one of only three enclaved countries in the world."
  ];

  // Inject main content
  const aboutSection = document.getElementById("about-content");
  aboutSection.innerHTML = `
    <h2>History & Culture</h2>
    <p>${aboutData.history}</p>
    <p id="extraText" style="display:none">
      ${aboutData.culture} <br><br> ${aboutData.attractions}
    </p>
  `;

  // Toggle button functionality
  const toggleBtn = document.getElementById("toggleBtn");
  const extraText = document.getElementById("extraText");

  toggleBtn.addEventListener("click", () => {
    if (extraText.style.display === "none") {
      extraText.style.display = "block";
      toggleBtn.textContent = "Show Less";
    } else {
      extraText.style.display = "none";
      toggleBtn.textContent = "Show More";
    }
  });

  // Show random fun fact
  document.getElementById("fun-fact").innerHTML = `
    <h3>Did You Know?</h3>
    <p>${funFacts[Math.floor(Math.random() * funFacts.length)]}</p>
  `;
}
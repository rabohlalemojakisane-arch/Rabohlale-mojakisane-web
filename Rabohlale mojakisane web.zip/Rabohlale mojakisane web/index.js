const welcomeMsg = document.getElementById("welcome-message");
if (welcomeMsg) {
  const now = new Date();
  welcomeMsg.textContent = `Hello Visitor! Today is ${now.toDateString()} - ${now.toLocaleTimeString()}`;
}
window.onload = Greetings;

function BackGround(){
  const colors = ["#350de6", "#ffffff", "#00ff66"];
  const random = Math.floor(Math.random() * colors.length);
  document.body.style.backgroundImage = 'none';
  document.body.style.backgroundColor = colors[random];
  document.body.style.background = colors[random];
}
window.BackGround = BackGround;

let slideIndex = 0;
const slides = [
  "valley.jpg",
  "images.jpg",
  "metsi.jpg"
];

function play(){
  const img = document.getElementById("Play") ;
  img.src = slides[slideIndex];
  }

function next(){
  slideIndex = (slideIndex + 1) % slides.length;
  play();
}

function previous(){
  slideIndex = (slideIndex - 1 + slides.length) % slides.length;
  play();
}
play()

setInterval(next, 3000);
